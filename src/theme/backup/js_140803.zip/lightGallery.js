/** ==========================================================

* jquery lightGallery.js v1.1.2
* http://sachinchoolur.github.io/lightGallery/
* Released under the Apache License - http://opensource.org/licenses/Apache-2.0  ---- FREE ----

* Modified with shorter id and class names by Gyorgy Papp <gyorgy.pap@gmail.com>
* Prettyfied with http://jsbeautifier.org/
* Last mod: Aug, 2014

=========================================================/**/
;
(function($) {
  "use strict";
  $.fn.lightGallery = function(options) {
    var defaults = {

				// Elements
				thumbnail   : true,  // Whether to display a button to show thumbnails.
				caption     : false, // Enables image captions. Content is taken from "data-title" attribute.
				captionLink : false, // Makes image caption a link. URL is taken from "data-link" attribute.
				desc        : false, // Enables image descriptions. Description is taken from "data-desc" attr.
				counter     : false, // Shows total number of images and index number of current image.
				controls    : true,  // Whether to display prev/next buttons.

				// Preload
				preload     : 1, // Number of preload slides.

				// Transitions
				mode   : 'slide',  // Type of transition between images. Either 'slide' or 'fade'.
				useCSS : true,     // Whether to always use jQuery animation for transitions or as a fallback.
				easing : 'linear', // Value for CSS "transition-timing-function" prop. and jQuery .animate().
				speed  : 1000,     // Transition duration (in ms).

				// Navigation
				hideControlOnEnd : false, // If true, prev/next button will be hidden on first/last image.
				loop             : false, // Allows to go to the other end of the gallery at first/last img.
				auto             : false, // Enables slideshow mode.
				pause            : 4000,  // Delay (in ms) between transitions in slideshow mode.
				escKey           : true,  // Whether lightGallery should be closed when user presses "Esc".

				// Mobile devices
				mobileSrc         : false, // If "data-responsive-src" attr. should be used for mobiles.
				mobileSrcMaxWidth : 640,   // Max screen resolution for alternative images to be loaded for.
				swipeThreshold    : 50,    // How far user must swipe for the next/prev image (in px).

				// Video
				vimeoColor    : 'CCCCCC', // Vimeo video player theme color (hex color code).
				videoAutoplay : true,     // Set to false to disable video autoplay option.
				videoMaxWidth : 855,      // Limits video maximal width (in px).

				// i18n
				lang : { allPhotos: 'All photos' }, // Text of labels.

				// Callbacks
				onOpen        : function() {}, // Executes immediately after the gallery is loaded.
				onSlideBefore : function() {}, // Executes immediately before each transition.
				onSlideAfter  : function() {}, // Executes immediately after each transition.
				onSlideNext   : function() {}, // Executes immediately before each "Next" transition.
				onSlidePrev   : function() {}, // Executes immediately before each "Prev" transition.
				onBeforeClose : function() {}, // Executes immediately before the start of the close process.
				onCloseAfter  : function() {}, // Executes immediately once lightGallery is closed.

				// Dynamical load
				dynamic   : false, // Set to true to build a gallery based on the data from "dynamicEl" opt.
				dynamicEl : [],    // Array of objects (src, thumb, caption, desc, mobileSrc) for gallery els.

				// Misc
				rel          : false, // Combines containers with the same "data-rel" attr. into 1 gallery.
				exThumbImage : false, // Name of a "data-" attribute containing the paths to thumbnails.

				// New
        closable : true,  // Close gallery when click on slide or not
        index    : false  // Open gallery with specified index or auto

      },
			selector = {
				body         : 'lg',
				container    : 'lg-out',
				gallery      : 'lg-gal',
				slider       : 'lg-slider',
				close        : 'lg-close',
				slide        : 'lg-slide',
				info         : 'lg-info',
				prev_control : 'lg-prev',
				next_control : 'lg-next',
				clearfix     : 'group',
			},
      el = $(this),
      $children,
      index,
      lightGalleryOn = false,
      html = '<div class="lg-out"><div class="lgal"><div class="lg-slider"></div><a class="lg-close close"><i class="icon-close"></i></a></div></div>',
      isTouch = document.createTouch !== undefined || ('ontouchstart' in window) || ('onmsgesturechange' in window) || navigator.msMaxTouchPoints,
      $gallery, $galleryCont, $slider, $slide, $prev, $next, prevIndex, $thumb_cont, $thumb, windowWidth, interval,
			usingThumb = false,
      aTiming = false,
      aSpeed = false;

    var settings = $.extend(true, {}, defaults, options);
    var lightGallery = {
      init: function() {
        el.each(function() {
          var $this = $(this);
          if (settings.dynamic == true) {
            $children = settings.dynamicEl;
            index = 0;
            prevIndex = index;
            setUp.init(index);
          } else {
            $children = $(this).children();
            $children.click(function(e) {
              if (settings.rel == true && $this.data('rel')) {
                var rel = $this.data('rel');
                $children = $('[data-rel="' + rel + '"]').children();
              } else {
                $children = $this.children();
              }
              e.preventDefault();
              e.stopPropagation();
              index = $children.index(this);
              prevIndex = index;
              setUp.init(index);
            });
          }
        });
      },
    };
    var setUp = {
      init: function() {
        this.start();
        this.build();
      },
      start: function() {
        this.structure();
        this.getWidth();
        this.closeSlide();
      },
      build: function() {
        this.autoStart();
        this.addCaption();
        this.addDesc();
        this.counter();
        this.slideTo();
        this.buildThumbnail();
        this.keyPress();
        if (settings.index) {
          this.slide(settings.index);
        } else {
          this.slide(index);
        }
        this.touch();
        this.enableTouch();

        setTimeout(function() {
          $gallery.addClass('opacity');
        }, 50);
      },
      structure: function() {
        $('body').append(html).addClass('lg');
        var $galleryCont = $('div.lg-out'),
					$gallery = $galleryCont.find('div.lgal'),
					$slider = $gallery.find('div.lg-slider');
        var slideList = '';
        if (settings.dynamic == true) {
          for (var i = 0; i < settings.dynamicEl.length; i++) {
            slideList += '<div class="lg-slide"></div>';
          }
        } else {
          $children.each(function() {
            slideList += '<div class="lg-slide"></div>';
          });
        }
        $slider.append(slideList);
        $slide = $slider.find('div.lg-slide');
      },
      closeSlide: function() {
        var $this = this;
        if (settings.closable) {
          $('div.lg-slide').on('click', function(event) {
						if ($(event.target).is('div.lg-slide')) {
							$this.destroy();
						}
          });
        }
        $('a.lg-close').bind('click touchend', function() {
          $this.destroy();
        });
      },
      getWidth: function() {
        var resizeWindow = function() {
          windowWidth = $(window).width();
        };
        $(window).bind('resize.lightGallery', resizeWindow());
      },
      doCss: function() {
        var support = function() {
          var transition = ['transition', 'MozTransition', 'WebkitTransition', 'OTransition', 'msTransition', 'KhtmlTransition'];
          var root = document.documentElement;
          for (var i = 0; i < transition.length; i++) {
            if (transition[i] in root.style) {
              return true;
            }
          }
					return false;
        };
        if (settings.useCSS && support()) {
          return true;
        }
        return false;
      },
      enableTouch: function() {
        var $this = this;
        if (isTouch) {
          var startCoords = {},
            endCoords = {};
          $('body').on('touchstart.lightGallery', function(e) {
            endCoords = e.originalEvent.targetTouches[0];
            startCoords.pageX = e.originalEvent.targetTouches[0].pageX;
            startCoords.pageY = e.originalEvent.targetTouches[0].pageY;
          });
          $('body').on('touchmove.lightGallery', function(e) {
            var orig = e.originalEvent;
            endCoords = orig.targetTouches[0];
            e.preventDefault();
          });
          $('body').on('touchend.lightGallery', function(e) {
            var distance = endCoords.pageX - startCoords.pageX,
              swipeThreshold = settings.swipeThreshold;
            if (distance >= swipeThreshold) {
              $this.prevSlide();
              clearInterval(interval);
            } else if (distance <= -swipeThreshold) {
              $this.nextSlide();
              clearInterval(interval);
            }
          });
        }
      },
      touch: function() {
				var $this = this,
        	xStart, xEnd,
					$gallery = $('div.lgal');
        $gallery.bind('mousedown', function(e) {
          e.stopPropagation();
          e.preventDefault();
          xStart = e.pageX;
        });
        $gallery.bind('mouseup', function(e) {
          e.stopPropagation();
          e.preventDefault();
          xEnd = e.pageX;
          if (xEnd - xStart > 20) {
            $this.prevSlide();
          } else if (xStart - xEnd > 20) {
            $this.nextSlide();
          }
        });
      },
      isVideo: function(src) {
        var youtube = src.match(/\/\/(?:www\.)?youtu(?:\.be|be\.com)\/(?:watch\?v=|embed\/)?([a-z0-9_\-]+)/i),
        	vimeo = src.match(/\/\/(?:www\.)?vimeo.com\/([0-9a-z\-_]+)/i);
        if (youtube || vimeo) {
          return true;
        }
				return false;
      },
      loadVideo: function(src, _id) {
        var youtube = src.match(/\/\/(?:www\.)?youtu(?:\.be|be\.com)\/(?:watch\?v=|embed\/)?([a-z0-9_\-]+)/i),
        	vimeo = src.match(/\/\/(?:www\.)?vimeo.com\/([0-9a-z\-_]+)/i),
					video = '',
        	a = '';
        if (youtube) {
          if (settings.videoAutoplay === true && lightGalleryOn === false) {
            a = '?autoplay=1&rel=0&wmode=opaque';
          } else {
            a = '?wmode=opaque';
          }
          video = '<iframe id="video' + _id + '" width="560" height="315" src="//www.youtube.com/embed/' + youtube[1] + a + '" frameborder="0" allowfullscreen></iframe>';
        } else if (vimeo) {
          if (settings.videoAutoplay === true && lightGalleryOn === false) {
            a = 'autoplay=1&amp;';
          } else {
            a = '';
          }
          video = '<iframe id="video' + _id + '" width="560" height="315"  src="http://player.vimeo.com/video/' + vimeo[1] + '?' + a + 'byline=0&amp;portrait=0&amp;color=' + settings.vimeoColor + '" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
        }
        return '<div class="video-cont" style="max-width:' + settings.videoMaxWidth + 'px !important;"><div class="video">' + video + '</div></div>';
      },
      loadContent: function(index, rec) {
        var $this = this,
					l = $children.length - index,
        	i, j,	src;
        if (settings.preload > $children.length) {
          settings.preload = $children.length;
        }
        if (settings.mobileSrc === true && windowWidth <= settings.mobileSrcMaxWidth) {
          if (settings.dynamic == true) {
            src = settings.dynamicEl[index]['mobileSrc'];
          } else {
            src = $children.eq(index).attr('data-responsive-src');
          }
        } else {
          if (settings.dynamic == true) {
            src = settings.dynamicEl[index]['src'];
          } else {
            src = $children.eq(index).attr('data-src');
          }
        }
        if (!$this.isVideo(src)) {
          if (!$slide.eq(index).hasClass('loaded')) {
            $slide.eq(index).prepend('<img src="' + src + '" />');
            $slide.eq(index).addClass('loaded');
          }
          if (rec === false) {
            var complete = false;
            if ($slide.eq(index).find('img')[0].complete) {
              complete = true;
            }
            if (!complete) {
              $slide.eq(index).find('img').on('load error', function() {
                var newIndex = index;
                for (var k = 0; k <= settings.preload; k++) {
                  if (k >= $children.length - index) {
                    break;
                  }
                  $this.loadContent(newIndex + k, true);
                }
                for (var h = 0; h <= settings.preload; h++) {
                  if (newIndex - h < 0) {
                    break;
                  }
                  $this.loadContent(newIndex - h, true);
                }
              });
            } else {
              var newIndex = index;
              for (var k = 0; k <= settings.preload; k++) {
                if (k >= $children.length - index) {
                  break;
                }
                $this.loadContent(newIndex + k, true);
              }
              for (var h = 0; h <= settings.preload; h++) {
                if (newIndex - h < 0) {
                  break;
                }
                $this.loadContent(newIndex - h, true);
              }
            }
          }
        } else {
          if (!$slide.eq(index).hasClass('loaded')) {
            if (rec === false && lightGalleryOn === true && settings.preload === 0) {
              setTimeout(function() {
                $slide.eq(index).prepend($this.loadVideo(src, index));
              }, settings.speed);
            } else {
              $slide.eq(index).prepend($this.loadVideo(src, index));
            }
            $slide.eq(index).addClass('loaded');

            if (settings.auto && settings.videoAutoplay === true) {
              clearInterval(interval);
            }
          }

          if (rec === false) {
            var complete = false;
            if ($slide.eq(index).find('iframe')[0].complete) {
              complete = true;
            }
            if (!complete) {
              $slide.eq(index).find('iframe').on('load error', function() {
                var newIndex = index;
                for (var k = 0; k <= settings.preload; k++) {
                  if (k >= $children.length - index) {
                    break;
                  }
                  $this.loadContent(newIndex + k, true);
                }
                for (var h = 0; h <= settings.preload; h++) {
                  $this.loadContent(newIndex - h, true);
                }
              });
            } else {
              var newIndex = index;
              for (var k = 0; k <= settings.preload; k++) {
                $this.loadContent(newIndex + k, true);
              }
              for (var h = 0; h <= settings.preload; h++) {
                $this.loadContent(newIndex - h, true);
              }
            }
          }
        }
      },
      addCaption: function() {
        if (settings.caption === true) {
          var i,
						j = $children.length,
						title = false;
          for (i = 0; i < j; i++) {
            if (settings.dynamic == true) {
              title = settings.dynamicEl[i]['caption'];
            } else {
              title = $children.eq(i).attr('data-title');
            }
            if (typeof title == 'undefined' || title == null) {
              title = 'image ' + i + '';
            }
            if (settings.captionLink === true) {
              var link = $children.eq(i).attr('data-link');
              if (typeof link !== 'undefined' && link !== '') {
                link = link
              } else {
                link = '#'
              }
              $slide.eq(i).append('<div class="lg-info clearfix"><a href="' + link + '" class="lg-title">' + title + '</a></div>');
            } else {
              $slide.eq(i).append('<div class="lg-info clearfix"><span class="lg-title">' + title + '</span></div>');
            }
          }
        }
      },
      addDesc: function() {
        if (settings.desc === true) {
          var i,
						j = $children.length,
						desc = false;
          for (i = 0; i < j; i++) {
            if (settings.dynamic == true) {
              desc = settings.dynamicEl[i]['desc'];
            } else {
              desc = $children.eq(i).attr('data-desc');;
            }
            if (typeof desc == 'undefined' || desc == null) {
              desc = 'image ' + i + '';
            }
            if (settings.caption === false) {
              $slide.eq(i).append('<div class="info group"><span class="desc">' + desc + '</span></div>');
            } else {
              $slide.eq(i).find('.info').append('<span class="desc">' + desc + '</span>');
            }
          }
        }
      },
      counter: function() {
        if (settings.counter === true) {
          var slideCount = $("div.lg-slider > div.lg-slide").length;
          $gallery.append("<div class='lg-counter'><span class='lg-counter-current'></span> / <span class='lg-counter-all'>" + slideCount + "</span></div>");
        }
      },
      buildThumbnail: function() {
        if (settings.thumbnail === true && $children.length > 1) {
          var $this = this;
          $gallery.append('<div class="thumb-cont"><div class="thumb-info"><span class="close-thumbs"><i class="icon-down"></i></span></div><div class="thumb-inner"></div></div>');
          $thumb_cont = $gallery.find('div.thumb-cont');
					$prev.after('<a class="open-thumbs"><i class="icon-thumbs"></i></a>');
          $gallery.find('a.open-thumbs').bind('click touchend', function() {
						$thumb_cont.addClass('open');
            if ($this.doCss() && settings.mode === 'slide') {
              $slide.eq(index).prevAll().removeClass('next-slide').addClass('prev-slide');
              $slide.eq(index).nextAll().removeClass('prev-slide').addClass('next-slide');
            }
          });
          $gallery.find('span.close-thumbs').bind('click touchend', function() {
            $thumb_cont.removeClass('open');
          });
          var thumbInfo = $gallery.find('div.thumb-info'),
          	$thumb_inner = $gallery.find('.thumb_inner'),
						thumbList = '',
						thumbImg;
          if (settings.dynamic == true) {
						var j = settings.dynamicEl.length;
            for (var i = 0; i < j; i++) {
              thumbImg = settings.dynamicEl[i]['thumb'];
              thumbList += '<div class="thumb"><img src="' + thumbImg + '" /></div>';
            }
          } else {
            $children.each(function() {
              if (settings.exThumbImage === false || typeof $(this).attr(settings.exThumbImage) == 'undefined' || $(this).attr(settings.exThumbImage) == null) {
                thumbImg = $(this).find('img').attr('src');
              } else {
                thumbImg = $(this).attr(settings.exThumbImage);
              }
              thumbList += '<div class="thumb"><img src="' + thumbImg + '" /></div>';
            });
          }
          $thumb_inner.append(thumbList);
          $thumb = $thumb_inner.find('div.thumb');
          $thumb.bind('click touchend', function() {
            usingThumb = true;
            var index = $(this).index();
            $thumb.removeClass('active');
            $(this).addClass('active');
            $this.slide(index);
            clearInterval(interval);
          });
          thumbInfo.prepend('<span class="count">' + settings.lang.allPhotos + ' (' + $thumb.length + ')</span>');
        }
      },
      slideTo: function() {
        var $this = this;
        if (settings.controls === true && $children.length > 1) {
					$gallery.append('<div class="lg-controls"><a class="lg-prev"><i class="icon-left"></i></a><a class="lg-next"><i class="icon-right"></i></a></div>');
					$prev = $gallery.find('a.lg-prev');
					$next = $gallery.find('a.lg-next');
          $prev.bind('click', function() {
            $this.prevSlide();
            clearInterval(interval);
          });
          $next.bind('click', function() {
            $this.nextSlide();
            clearInterval(interval);
          });
        }
      },
      autoStart: function() {
        var $this = this;
        if (settings.auto === true) {
          interval = setInterval(function() {
            if (index + 1 < $children.length) {
              index = index;
            } else {
              index = -1;
            }
            index++;
            $this.slide(index);
          }, settings.pause);
        }
      },
      keyPress: function() {
        var $this = this;
        $(window).bind('keyup.lightGallery', function(e) {
          e.preventDefault();
          e.stopPropagation();
          if (e.keyCode === 37) {
            $this.prevSlide();
            clearInterval(interval);
          }
          if (e.keyCode === 38 && settings.thumbnail === true) {
            if (!$thumb_cont.hasClass('open')) {
              if ($this.doCss() && settings.mode === 'slide') {
								$slide.eq(index).prevAll().removeClass('next-slide').addClass('prev-slide');
								$slide.eq(index).nextAll().removeClass('prev-slide').addClass('next-slide');
              }
              $thumb_cont.addClass('open');
            }
          } else if (e.keyCode === 39) {
            $this.nextSlide();
            clearInterval(interval);
          }
          if (e.keyCode === 40 && settings.thumbnail === true) {
            if ($thumb_cont.hasClass('open')) {
              $thumb_cont.removeClass('open');
            }
          } else if (settings.escKey === true && e.keyCode === 27) {
            if (settings.thumbnail === true && $thumb_cont.hasClass('open')) {
              $thumb_cont.removeClass('open');
            } else {
              $this.destroy();
            }
          }
        });
      },
      nextSlide: function() {
        var $this = this;
        index = $slide.index($slide.eq(prevIndex));
        if (index + 1 < $children.length) {
          index++;
          $this.slide(index);
        } else {
          if (settings.loop) {
            index = 0;
            $this.slide(index);
          } else if (settings.mode === 'fade' && settings.thumbnail === true && $children.length > 1) {
            $thumb_cont.addClass('open');
          }
        }
        settings.onSlideNext.call(this);
      },
      prevSlide: function() {
        var $this = this;
        index = $slide.index($slide.eq(prevIndex));
        if (index > 0) {
          index--;
          $this.slide(index);
        } else {
          if (settings.loop) {
            index = $children.length - 1;
            $this.slide(index);
          } else if (settings.mode === 'fade' && settings.thumbnail === true && $children.length > 1) {
            $thumb_cont.addClass('open');
          }
        }
        settings.onSlidePrev.call(this);
      },
      slide: function(index) {
        this.loadContent(index, false);
        if (lightGalleryOn) {
          if (!$slider.hasClass('on')) {
            $slider.addClass('on');
          }
          if (this.doCss() && settings.speed !== '') {
            if (!$slider.hasClass('speed')) {
              $slider.addClass('speed');
            }
            if (aSpeed === false) {
              $slider.css('transition-duration', settings.speed + 'ms');
              aSpeed = true;
            }
          }
          if (this.doCss() && settings.easing !== '') {
            if (!$slider.hasClass('timing')) {
              $slider.addClass('timing');
            }
            if (aTiming === false) {
              $slider.css('transition-timing-function', settings.easing);
              aTiming = true;
            }
          }
          settings.onSlideBefore.call(this);
        }
        if (settings.mode === 'slide') {
          var isiPad = navigator.userAgent.match(/iPad/i) != null;
          if (this.doCss() && !$slider.hasClass('slide') && !isiPad) {
            $slider.addClass('slide');
          } else if (this.doCss() && !$slider.hasClass('useLeft') && isiPad) {
            $slider.addClass('useLeft');
          }
          if (!this.doCss() && !lightGalleryOn) {
            $slider.css({
              left: (-index * 100) + '%'
            });
          } else if (!this.doCss() && lightGalleryOn) {
            $slider.animate({
              left: (-index * 100) + '%'
            }, settings.speed, settings.easing);
          }
        } else if (settings.mode === 'fade') {
          if (this.doCss() && !$slider.hasClass('fadeM')) {
            $slider.addClass('fadeM');
          } else if (!this.doCss() && !$slider.hasClass('animate')) {
            $slider.addClass('animate');
          }
          if (!this.doCss() && !lightGalleryOn) {
            $slide.fadeOut(100);
            $slide.eq(index).fadeIn(100);
          } else if (!this.doCss() && lightGalleryOn) {
            $slide.eq(prevIndex).fadeOut(settings.speed, settings.easing);
            $slide.eq(index).fadeIn(settings.speed, settings.easing);
          }
        }
        if (index + 1 >= $children.length && settings.auto && settings.loop === false) {
          clearInterval(interval);
        }
        $slide.eq(prevIndex).removeClass('current');
        $slide.eq(index).addClass('current');
        if (this.doCss() && settings.mode === 'slide') {
          if (usingThumb === false) {
						$('.prev-slide').removeClass('prev-slide');
						$('.next-slide').removeClass('next-slide');
						$slide.eq(index - 1).addClass('prev-slide');
						$slide.eq(index + 1).addClass('next-slide');
					} else {
						$slide.eq(index).prevAll().removeClass('next-slide').addClass('prev-slide');
						$slide.eq(index).nextAll().removeClass('prev-slide').addClass('next-slide');
          }
        }
        if (settings.thumbnail === true && $children.length > 1) {
          $thumb.removeClass('active');
          $thumb.eq(index).addClass('active');
        }
        if (settings.controls && settings.hideControlOnEnd && settings.loop === false && $children.length > 1) {
          var l = $children.length;
          l = parseInt(l) - 1;
          if (index === 0) {
            $prev.addClass('disabled');
            $next.removeClass('disabled');
          } else if (index === l) {
            $prev.removeClass('disabled');
            $next.addClass('disabled');
          } else {
            $prev.add($next).removeClass('disabled');
          }
        }
        prevIndex = index;
        lightGalleryOn === false ? settings.onOpen.call(this) : settings.onSlideAfter.call(this);
        lightGalleryOn = true;
        usingThumb = false;
        if (settings.counter) {
					$("span.lg-counter-current").text(index + 1);
        }
      },
      destroy: function() {
        settings.onBeforeClose.call(this);
        lightGalleryOn = false;
        aTiming = false;
        aSpeed = false;
        usingThumb = false;
        clearInterval(interval);
        $('.lgal').off('mousedown mouseup');
        $('body').off('touchstart.lightGallery touchmove.lightGallery touchend.lightGallery');
        $(window).off('resize.lightGallery keyup.lightGallery');
        $gallery.addClass('fadeM');
        setTimeout(function() {
          $galleryCont.remove();
          $('body').removeClass('lgal');
        }, 500);
        settings.onCloseAfter.call(this);
      }
    };
    lightGallery.init();
    return this;
  };
}(jQuery));