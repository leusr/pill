
// mobileNav plugin
function mobileNav ( options ) {

  var toggler = $( options.navToggler ),
    nav = $( options.navMenu ),
    level0 = nav.find( '> li' ),
    level1 = level0.find( '> ul > li' );

  // Attach show menu event
  toggler.on( 'click', function () {
    nav.toggle();
  });

  // Spans are only navitems that has children.
  // Add down icons to it
  nav.find( 'span' ).addClass( 'subnav-control' ).prepend( '<i class="icon-down-sm"></i>' );

  // Prepare close and back items
  var closeNavLI = '<li><span class="close-nav"><i class="icon-close"></i>Menü bezárása</span></li>',
    backNavLI = '<li><span class="back-nav"><i class="icon-up-sm"></i>Vissza</span></li>';
  nav.append( closeNavLI );

  // Add back items
  var backNavLI = '<li><span class="back-nav"><i class="icon-up-sm"></i>Vissza</span></li>';
  nav.find( 'li ul' ).append( backNav );

  // Attach close nav event
  nav.find( 'span.close-nav' ).on( 'click', function () {
    nav.hide();
  });

  // Subnav open
  level0.find( '> span.subnav-control' ).on( 'click', function () {
    var _this = $( this );
    var subnav = _this.parent().find( '> ul' );

    // Show/hide
    level0.hide();
    _this.hide();
    _this.parent().show();
    subnav.show();

    // Attach back event
    var back = _this.parent().find('> ul > li > span.back-nav');
    back.on( 'click', function () {
      subnav.hide();
      _this.show();
      level0.show();
    });
  });

  // Subnav level1 open
  level1.find( '> span.subnav-control' ).on( 'click', function () {
    var _this = $( this );
    var subnav = _this.parent().find( '> ul' );
    var prevlevel = level0.find( '> ul > li' );

    prevlevel.hide();
    _this.hide();
    _this.parent().show();
    subnav.show();

    // Attach back level1 event
    var back = _this.parent().find('> ul > li > span.back-nav');
    back.on( 'click', function () {
      subnav.hide();
      _this.show();
      prevlevel.show();
    });
  });

}
